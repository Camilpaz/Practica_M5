--4. Construye las siguientes consultas:
--• Aquellas usadas para insertar, modificar y eliminar un Customer, Staff y Actor

-- CUSTOMER

INSERT INTO address VALUES
(DEFAULT, '1234 Jardin de flores', null, 'Rio Grandede do sul', '21', '26284', '56912345678', '2024-10-01 00:00:00');
INSERT INTO customer VALUES
(DEFAULT, '2', 'Camila', 'Palma', 'camila.palma@sakilacustomer.org', '606', 'true', '2024-10-01', '2024-10-01 00:00:00.738', '1')

UPDATE customer SET last_name = 'Tolvett' WHERE customer_id= 600;

DELETE FROM rental where customer_id = 1;
DELETE FROM payment where customer_id = 1;
DELETE FROM customer where customer_id = 1

SELECT * FROM customer

--STAFF

INSERT INTO staff VALUES
(DEFAULT, 'Juan', 'Perez', '606', 'juan.perez@sakilastaff.com', '2', 'true', 'Juan', '8cb2237d0679ca88db6464eac60da96345513964','2024-10-01 00:00:00.738' , null);

UPDATE staff SET last_name = 'Smith' WHERE staff_id= 2; 

DELETE FROM staff where staff_id = 3

SELECT * FROM staff

--ACTOR

INSERT INTO actor VALUES
(DEFAULT, 'Jose', 'Vidal', '2024-10-01 00:00:00.738');

UPDATE actor SET last_name = 'Soto' WHERE actor_id= '1'; 

DELETE FROM film_actor where actor_id= '2';
DELETE FROM actor where actor_id= '2'

SELECT * FROM actor

-- Listar todas las “rental” con los datos del “customer” dado un año y mes.

CREATE VIEW public.rental_customer
 AS
SELECT r.customer_id, c.first_name, c.last_name, r.rental_date
FROM rental r  
JOIN customer c
ON r.customer_id = c.customer_id
WHERE rental_date BETWEEN '2005-06-01' AND '2005-07-01'
ORDER BY rental_date;

--• Listar Número, Fecha (payment_date) y Total (amount) de todas las “payment”.

CREATE VIEW public.paymet_date_amount
 AS
SELECT p.payment_id, p.payment_date, p.amount
FROM payment p
ORDER BY payment_id;


--• Listar todas las “film” del año 2006 que contengan un (rental_rate) mayor a 4.0.

CREATE VIEW public.films_rate_2006
 AS
SELECT f.rental_rate, f.title, f.release_year  FROM film f
WHERE rental_rate >= '4.0' AND release_year = '2006'
ORDER BY title;

/*
5. Realiza un Diccionario de datos que contenga el nombre de las tablas y columnas, si
éstas pueden ser nulas, y su tipo de dato correspondiente.
*/

CREATE VIEW public.diccionary_table_column_null_data
 AS
SELECT
	t1.TABLE_NAME AS tabla_nombre,
    t1.COLUMN_NAME AS columna_nombre,
	t1.IS_NULLABLE AS es_nulo,
	t1.DATA_TYPE AS tipo_dato
FROM 
    INFORMATION_SCHEMA.COLUMNS t1
    INNER JOIN PG_CLASS t2 ON t2.RELNAME = t1.TABLE_NAME
WHERE 
    t1.TABLE_SCHEMA = 'public'
ORDER BY
    t1.TABLE_NAME;